function sphere_vol(r)
   return 4/3*pi*r^3
end

sphere_vol(2.5)
