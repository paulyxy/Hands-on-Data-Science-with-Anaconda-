"""
  Name     : c11_02_myfincal.py
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 5/8/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import fincal
x=dir(fincal)
print(x)
