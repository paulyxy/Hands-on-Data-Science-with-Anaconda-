"
  Name     : c5_22_ff5.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"


con<-url("http://canisius.edu/~yany/RData/ff5monthly.RData")
load(con)
head(.ff5monthly)
