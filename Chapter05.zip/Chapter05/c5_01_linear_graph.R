"
  Name     : c5_01_linear_graph.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

x<--10:10
y<-2+1.5*x
title<-"A straight line"
plot(x,y,type='l',main=title)

