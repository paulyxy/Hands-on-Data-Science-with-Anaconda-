
###
  Name     : c5_28_run_program.jl
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
###


# assume that helloworld.jl has the following one line. 
# println("Hello world")


 include("c:/temp/helloWorld.jl")