"
  Name     : c5_13_critical_Tvalue.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

alpha<-0.01
degreeFreedom<-50
qt(1-alpha/2,degreeFreedom)


