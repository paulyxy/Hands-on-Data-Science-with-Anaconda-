"
  Name     : c5_24_critical_value_F_distribution.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

 alpha<-0.1
 d1<-1
 d2<-1
 qf(1-alpha,df1=d1,df2=d2)
