"
  Name     : c12_17_taskView.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 5/14/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

install.packages("ctv")
library("ctv")
install.views("HighPerformanceComputing")
