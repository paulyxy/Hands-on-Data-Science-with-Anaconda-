
"
  Name     : c9_36_taskView_machineLearning.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 4/6/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

install.packages("ctv")
library("ctv")
install.views("MachineLearning")
