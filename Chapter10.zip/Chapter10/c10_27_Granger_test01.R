"
  Name     : c10_27_Grander_test01.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 4/24/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

library(lmtest)
data(ChickEgg)
dim(ChickEgg)
ChickEgg[1:5,]


