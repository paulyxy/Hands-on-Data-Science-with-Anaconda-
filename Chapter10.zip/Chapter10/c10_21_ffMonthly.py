"""
  Name     : c10_21_ffMonthly.py
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 4/24/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""


import pandas as pd
ff=pd.read_pickle("c:/temp/ffMonthly.pkl")
print(ff.head())

