"
  Name     : c3_18_missing_code_apropos.R
  Book     : Hands-on Data Science with Anaconda)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/15/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

> apropos("^na")
 [1] "na.action"              "na.contiguous"          "na.exclude"            
 [4] "na.fail"                "na.omit"                "na.pass"               
 [7] "na_example"             "names"                  "names.POSIXlt"         
[10] "names<-"                "names<-.POSIXlt"        "namespaceExport"       
[13] "namespaceImport"        "namespaceImportClasses" "namespaceImportFrom"   
[16] "namespaceImportMethods" "napredict"              "naprint"               
[19] "naresid"                "nargs"                 
