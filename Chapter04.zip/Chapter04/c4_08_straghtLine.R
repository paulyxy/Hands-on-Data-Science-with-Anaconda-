"
  Name     : c4_08_straightLine.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

 x<-seq(-3,3,by=0.05)
 y<-2+2.5*x
 plot(x,y,type="b")

