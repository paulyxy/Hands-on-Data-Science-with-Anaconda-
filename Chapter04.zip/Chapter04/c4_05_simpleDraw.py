"
  Name     : c4_05_simpleDraw.py
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

import matplotlib.pyplot as plt 
plt.plot([2,3,8,12])
plt.show()

