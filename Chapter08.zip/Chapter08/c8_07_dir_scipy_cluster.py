"""
  Name     : c8_07_dir_scipy_cluster.py
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 3/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""


import scipy.cluster as cluster
x=dir(cluster)
print(x)

