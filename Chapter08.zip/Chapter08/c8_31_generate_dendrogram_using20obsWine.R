"
  Name     : c8_31_generate_dendrogram_using20obsWine.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 3/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"


library(rattle.data)
data(wine)
x<-head(wine,10)

library(rattle)
rattle()

# choose R data set
# choose x
# hit Execute
# choose cluster
# hit Execute
# choose Dendrogram
