"
  Name     : c8_19_5points.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 3/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

data <- rbind(c(180,20), c(160,5), c(60, 150), c(160,60), c(80,120))
plot(data, col = "red", lwd = 20)


