"""
  Name     : c7_00_optimize_help.py
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 3/1/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import scipy as sp
x=dir(sp.optimize)
print(x)


#import numpy as np

from scipy.optimize import minimize
help(minimize)
