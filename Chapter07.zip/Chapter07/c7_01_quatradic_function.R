"
  Name     : c7_01+qiatradoc+fimctopm.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 3/15/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

 x<-seq(-10,10,0.1)
 a<--2
 b<-10
 c<-5
 y<-a*x^2+b*x+c
 plot(x,y,type='l')
