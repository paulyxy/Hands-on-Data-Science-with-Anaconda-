"
  Name     : c6_05_taskViewFinance.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 3/1/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

install.packages("ctv")
library("ctv")
install.views("Finance")
