"
  Name     : c6_03_read_csv.R
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 3/1/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

x<-read.csv("http://canisius.edu/~yany/data/ibmDaily.csv")