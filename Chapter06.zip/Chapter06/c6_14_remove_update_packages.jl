###
  Name     : c6_14_remove_uudate_package.jl
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/25/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
###


Pkg.rm("AbstractTable")

Pkg.update()

