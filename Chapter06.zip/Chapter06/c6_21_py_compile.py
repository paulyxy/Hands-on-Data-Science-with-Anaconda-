"""
  Name     : c6_21_py_compile.py
  Book     : Hands-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 3/1/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""


import py_compile
py_compile.compile('c:/temp/myPackage.py')
