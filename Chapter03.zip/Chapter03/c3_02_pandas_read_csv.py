"""
  Name     : c3_02_pandas_read_csv.py
  Book     : Hans-on Data Science with Anaconda )
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/15/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"""

import pandas as pd
data=pd.read_csv("c://temp/bezdekIris.data.txt",header=None)

