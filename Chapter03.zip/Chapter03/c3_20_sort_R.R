"
  Name     : c3_20_sort.R
  Book     : Hands-on Data Science with Anaconda)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan and James Yan
  Date     : 1/15/2018
  email    : yany@canisius.edu
             paulyxy@hotmail.com
"

set.seed(123)
x<-rnorm(100)
head(x)
y<-sort(x)
head(y)


